import dotenv from "dotenv";
dotenv.config();

import pg from "pg";
import bcrypt from "bcryptjs";

const { Pool } = pg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function slugify(title) {
  return title
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

function excerptOf(content) {
  const firstLines = content.split("\n").filter(Boolean).slice(0, 2).join(" ");
  return firstLines.length > 160 ? firstLines.slice(0, 157) + "..." : firstLines;
}

const poems = [
  {
    title: "Toi, la femme de ma vie",
    category: "Amour",
    featured: true,
    content: `Toi, la femme de ma vie,
Celle qui m'a redonné goût à la vie.
Avec un simple sourire,
Tu changes mes larmes en fous rires.

J'aimerais te dire merci,
D'avoir comblé ce grand vide en moi,
Un vide fait de doutes et de conflits
Entre mon cœur et mon esprit.

Un jour timide, deux cœurs en silence,
Des regards volés, une douce espérance.
À force d'attendre, de douter, de rêver,
Te voilà plus proche, et tout devient léger.

Quand tu es là, le temps s'arrête,
Même les silences deviennent des fêtes.
Et quand tu souris, mon monde s'illumine,
Comme si ton âme apaisait la mienne sans limite divine.

Je t'aime maintenant, et à l'infini,
Chaque jour un peu plus, pour toute la vie.`,
  },
  {
    title: "Toi, la reine de mon cœur",
    category: "Amour",
    featured: true,
    content: `Toi, la reine de mon cœur,
La plus belle, la plus douce des fleurs,
Anéantissant toutes mes peurs,
Ma joie, ma peine, tu dictes mes humeurs.

Mes sentiments pour toi ne cessent de croître,
Même si j'aimerais vraiment y croire,
Dans le doute, je me perds chaque soir,
Car chaque pas vers toi,
Te fait, hélas, t'éloigner de moi.

Et pourtant, sans trop savoir pourquoi,
Je garde au fond de moi cet espoir-là :
Qu'un jour, tu verras en moi
La flamme sincère qui brûle pour toi.

J'aimerais tant te faire ma déclaration,
Mais la peur de briser notre connexion
Me retient, m'enchaîne à la frustration…
Alors j'attends, j'attends sans précipitation.

Je choisis le silence, mais mon regard te parle,
Il crie tout bas ce que mon cœur emballe.
Chaque sourire que tu m'offres est une lumière,
Mais chaque "ami" que tu dis est une barrière.

Je ne veux rien forcer, ni précipiter,
Juste t'aimer, t'écouter, te respecter.
Mais si un jour ton cœur veut s'ouvrir,
Je serai là… prêt à t'accueillir.`,
  },
  {
    title: "Un regard qui s'égare, un silence de trop",
    category: "Amour",
    content: `Un regard qui s'égare, un silence de trop,
Des pensées qui cognent, qui frappent là-haut.
Dis-moi sans détour, sans masque, sans voile,
Qu'est-ce que je suis pour toi, au fond des étoiles ?

Tes gestes sont doux, tes sourires me parlent,
Mais tes mots hésitent, ton silence m'accable.
Un jour j'ai l'impression d'être tout près du cœur,
Le suivant, je me perds dans un goût de douleur.

Dans mes rêves, tu brilles, tu ris, tu existes,
Mais dans les tiens… est-ce que j'en fais juste partie?
Quand tu m'approches, quand tu me frôles,

Je ne veux pas forcer, ni voler ton choix,
Je veux juste comprendre ce qui naît ou pas.
Si je ne suis qu'un ami, alors dis-le-moi,
Mais si c'est plus que ça… laisse parler ta voix.

Même flou, même fragile, même mal défini,
Je préfère un soupir qu'un silence poli.
Je veux juste savoir, ne plus deviner,
Car le doute, lui, me fait chavirer.`,
  },
  {
    title: "Dans l'ombre, je tombe, sans bruit je me redresse",
    category: "Amour",
    content: `Dans l'ombre, je tombe, sans bruit je me redresse,
Le cœur en désordre, l'âme pleine de détresse.
Ton regard me trouble, tes gestes m'égarent,
Et pourtant je reste… même si tout me sépare.

Je veux mon bien, quitte à briser le lien,
Car l'amour quand il blesse, n'apporte plus rien.
Ton sourire m'éclaire, mais m'écorche aussi,
C'est une lumière douce... qui me laisse meurtri.

Te voir près de lui, sentir que tu t'éloignes,
Cette jalousie m'étreint, ce silence me poignarde.
Quand il t'enlace, quand il t'appartient,
Je me perds dans l'ombre, impuissant, incertain.

Mon souffle s'arrête, mes pensées se brouillent,
Ton bonheur ailleurs fait que mon cœur s'écroule.
Ce n'est pas juste un coup c'est un feu permanent,
Une douleur sincère, un amour dévorant.

Je t'ai aimée, respectée, placée si haut,
Peut-être trop fort, peut-être trop tôt.
Mais comment ignorer cette douce connexion,
Quand chaque instant passé nourrit mon affection ?

J'aurais voulu que ce soit partagé,
Mais l'amour ne s'impose, il vient ou s'en va léger.
Je comprends ton cœur, même s'il fuit le mien,
Et je recule… pour que tu suives ton chemin.

Je me relève, je me soigne, je pardonne,
Espérant qu'un jour cette douleur s'étonne
D'avoir été si vive, si vaste, si vraie,
Et qu'elle s'apaise enfin, sans regrets.

Ne m'oublie pas, même si la vie t'emmène,
Car moi, dans le silence, je te garde… sans haine.`,
  },
  {
    title: "J'ai aimé sans bruit, sans arme, sans détour",
    category: "Amour",
    content: `J'ai aimé sans bruit, sans arme, sans détour,
le cœur ouvert, frêle, au milieu du jour.
Je croyais que sentir faisait loi,
que vibrer fort suffisait parfois.

Il y avait elle, ni flamme, ni ange,
juste assez humaine pour que mon âme change.
Ses silences parlaient, ses ombres dansaient,
et j'apprenais que l'amour n'est pas toujours choisi, jamais.

Elle m'apportait joie, douleur, lumière et vent,
transformant le banal en un feu éclatant.
Chaque éclat, chaque rire, chaque geste volé
gravait son nom dans mes nuits, dans mes pensées.

Je croyais contrôler, mais son regard me fuyait,
brisant mes murs, emportant mon nord, me guidait.
J'aimais ses failles, ses ombres imparfaites,
ses éclats, ses vertiges, ses zones secrètes.

Puis j'ai compris ce que je cherchais vraiment :
je n'aimais pas ce qu'elle donnait, mais ce que je devenais dedans.
Un cœur ouvert, vulnérable et nu,
un moi sincère que je n'avais jamais connu.

Et quand elle n'a pas choisi,
ce n'est pas mon cœur qui s'est brisé,
c'est l'illusion que sentir suffisait
pour combler le vide que le monde refusait.

Aujourd'hui tout s'apaise, tout se rassemble,
je vois plus clair, je tremble moins il me semble.
Je n'ai rien perdu, j'ai appris à rester,
aimer sans me perdre, sentir sans m'effacer.

Je marche entier, sans fuite ni armure,
prêt à aimer quand l'amour sera pur.
Et au fond de moi, je sais enfin :
je peux aimer sincèrement, sans jamais perdre rien.`,
  },
  {
    title: "Il y a des présences qui traversent le temps",
    category: "Admiration",
    content: `Il y a des présences qui traversent le temps,
Comme un souffle léger qui reste constamment.
Ton rire est un écho qui danse dans l'air,
Un éclat de soleil dans les ombres éphémères.

Tu marches, et le monde semble retenir son souffle,
Chaque geste, chaque sourire, chaque mot qui s'essouffle.
Il y a dans tes yeux une mer profonde et claire,
Où l'on pourrait se perdre sans jamais se défaire.

Femme de courage, d'esprit et de chaleur,
Tu sais mêler force et infinie douceur.
Même un simple geste, un petit éclat de toi,
Réveille la curiosité, la vie, et parfois la joie.

Ton aura touche ceux qui ont la chance de t'approcher,
Mais jamais par désir de posséder, juste d'admirer.
Car tu es entière, libre, et tu brilles sans bruit,
Comme une étoile qui veille sur la nuit.

Je garde dans mon cœur ce que je ne peux dire,
Le respect, l'émerveillement, le plaisir de te voir sourire.
Même si la vie a choisi d'autres chemins pour nous,
Ton image reste, douce, lumineuse, et précieuse comme un bijou.

Et si un jour nos routes ne font que se croiser,
Je saurai simplement sourire, et te saluer.
Car certaines âmes méritent d'être admirées
Sans jamais rien demander, juste les apprécier.`,
  },
  {
    title: "J'ai donné tout ce que j'avais",
    category: "Amour",
    content: `J'ai donné tout ce que j'avais,
Mon cœur, mes rires, mes secrets.
Pour elles, je me suis offert,
Protecteur, attentif, sincère.

Mais leurs yeux ne voyaient que l'ami,
Le frère tendre, jamais l'infini.
Et moi je tombais, encore et encore,
Dans l'espoir qu'un jour elles m'aiment un peu plus fort.

Chaque compliment, chaque sourire,
Était un souffle doux, mais qui me fait frémir.
Car sous la lumière, je porte la fatigue,
D'un cœur qui aime et se fatigue.

Pourtant je tiens, je continue,
Car ce que je suis, personne ne le diminue.
Et un jour viendra celle qui verra,
Le feu, la tendresse, et mon aura.

Entre amitié et désir jamais réciproque,
Je marche, je tombe, mais je reste équivoque.
Car aimer ne diminue pas ma valeur,
Et mon cœur saura trouver la chaleur.`,
  },
  {
    title: "Le silence me pèse, le vide m'agace",
    category: "Mélancolie",
    content: `Le silence me pèse, le vide m'agace
Mon cœur se resserre, et moi je me lasse
Je rêve le jour, je veille la nuit
Je souris toujours… mais je pleure aussi

Mes pensées me rongent, son sourire me comble
Le reflet de mes pupilles cache une âme fragile
Mes peurs, mes rires, des émotions illusoires.
Fou je crie. Frêle je suis.

À force de survivre, je ne sais plus sourire
Et dans le déni, je plonge dans les abysses
Émietté, brisé… la différence inexistante
Définissant ma nature sous mon masque social`,
  },
  {
    title: "Le jour je brille, le soir je m'efface",
    category: "Mélancolie",
    content: `Le jour je brille, le soir je m'efface,
Sous des faux sourires qui cachent ma face.
Je fais des vœux dans le vent qui me glace,
Pendant que la vie m'embrasse puis me lâche.

Dans la peur je vis, pourtant je ris,
Des rires légers que mon cœur trahit.
Des éclats perdus dans un bruit infini,
Comme une âme forte qui lentement s'oublie.

Mon âme me parle dans un doux silence,
Mon cœur se voile d'une étrange absence.
Et comme une fleur perdue dans l'immense,
Je me fane seul dans l'indifférence.
Un spectacle sombre, invisible aux yeux,
Où mon monde s'effondre sans bruit sous les cieux.

Je deviens l'écho d'un moi malheureux,
Un personnage flou, perdu dans les adieux.
Des petites douleurs, simples au début,
Se sont transformées en tempêtes absolues.
Elles creusent en moi des chemins inconnus,
Où mes pensées sombrent, sans retour, sans salut.

Dis-moi la vérité que je cherche en vain,
Est-ce la vie elle-même qui serre mes mains ?
Ou suis-je perdu dans mes propres chemins,
À chercher du sens dans des mondes incertains ?

La vie est-elle lutte, combat sans repos,
Ou simple reflet de nos propres fardeaux ?
Et dans ce mystère, lourd comme un tombeau,
Je cherche encore une lumière en écho.....`,
  },
  {
    title: "Paradis/Enfer",
    category: "Amour",
    content: `Calme comme le vent, lumineuse telle une étoile,
Un paradis tu es, mais difficile d'accès.
Dans une saison de doute, de stress, de deuil,
J'aperçus une lueur : c'était toi.

Hésitant, confus, troublé, j'osai le premier pas.
Dès ton regard, dès nos premiers mots, je sentis mes peurs, mes cicatrices, mes insécurités s'évaporer.
Avec toi, le temps se figeait, telle une horloge sans aiguilles, et mon âme s'ancrait à la tienne à chaque sourire.

Attiré, curieux, fébrile, semblable à un gamin en extase devant un animé,
Assoiffé déjà du prochain échange sitôt le dernier fini.
Princesse en tes mots, reine en mes yeux, résidant dans mon cœur.

Mais l'Éden promis n'était qu'un mirage.
Plus incertain qu'avant, j'avançais dans un champ d'épines, à l'aveugle.
Gonflées par mes doutes, mes blessures devinrent des gouffres.

Je feignais d'aller bien, pourtant j'étais en ruine, persuadé que nul ne saurait comprendre.
Submergé de chagrin, trahi par mon imagination, je portais un masque de roc sur un corps de verre.

De cette histoire, que garder ? De mes chutes, qu'ai-je appris ? Ces questions me hantent, obstinées.
Ce nous, ce lien, ce vertige… je l'ignore encore. Mais je le dirais ainsi : un soleil brillant devenu une étoile filante.`,
  },
  {
    title: "Silence bruyant",
    category: "Réflexion",
    content: `Le soir sur mon lit, assis seul dans le noir
Des pensées surgissent, un peu philosophiques, je crois
Tel un coup de cœur auditif résonant sans cesse
Des questions existentielles dans la peau de Socrate
Des idées, des croyances, des évidences toutes différentes
Reliées par une vérité que je comprends finalement ;
"À part nous, nous ne contrôlons rien"
Et hélas la vie n'est guère un schéma

Je restais dans ma zone de confort
Confondant mérite et compatibilité
Pensant qu'avec acharnement et dévotion
Même l'impossible me viendrait gratuit
Alors pendant des mois, non des années
Je chassais l'idéal en m'idéalisant
Fuyant mes peurs, mes doutes et mes désobéissances

Confiant je suis, mais réaliste étais-je ?
J'ai mes chances, je proclamais
Sans savoir que jamais ça ne marcherait
Gentil, présent, attentionné j'étais
Blessé, déçu, frustré je finissais
Un cercle vicieux le décrirais-je
Peut-être sans fin, presque perpétuel

Après plusieurs rejets, après plusieurs introspections
Étaye-moi le problème ?
Quelle est donc ma valeur ?
Ma confiance, mon ego, mon estime de soi
Tout réduit à néant, tout remis à zéro

Et dans ce chagrin d'amour
Les secondes devinrent des jours
Redonnant sens au mot éternel

Devrais-je m'arrêter là ou continuer à me battre
Toi qui lis ce poème, qu'aurais-tu fait à ma place
T'attendais-tu à une fin heureuse ? Moi aussi
Mais hélas la vie n'est point un conte de fées
Où tous les malheurs finissent par s'apaiser`,
  },
  {
    title: "Rencontre imagé",
    category: "Réflexion",
    content: `Des rencontres inattendues,
Des attachements inopinés.
Un petit récit ou une histoire profonde,
Un dilemme discret à l'impact réel.

Souvent des gens, souvent des anges,
Sans connaître leur nom, sans connaître leur âge.
Des liens qui se tissent, parfois si fragiles,
Avec pour carburant des rires,
Avec pour moteur des souvenirs.

Tel un aimant face à un autre,
Parfois s'attirent, parfois se repoussent.
C'est le socle de la vie,
Mais je ne l'avais jamais compris.

De pôles similaires nous étions,
Un point en commun nous avions.
Hélas, nous nous repoussions.
Ce lien, plus qu'un lien... je me bats contre la nature,
Devenant un plastique que tu n'attirais point,
M'adaptant en métal pour me rapprocher, peut-être.

Le changement aide, mais pour celles qui l'attendent...
Et tout finit sans fin tragique.
Quel rôle as-tu dans ce film ?
Une connaissance ou une amie ?
Je ne sais comment décrire
Ce qui désormais n'est plus qu'un souvenir.`,
  },
  {
    title: "Jardin de vie",
    category: "Vie",
    content: `Dans une prairie, je vis trois petits canaris
Se baladant sur l'herbe verte, sous un soleil vif,
Tous de couleur blanche, avec des becs gris.
Marchant en synchronie, ce qui m'ébahit.

Des colonies de fourmis sous le vieux tapis...
« Mais combien sont-ils ? » me demanda Julie.
Si petits, si fragiles, et un peu naïfs,
Selon mes dires jadis. Puis je compris
Que l'humain n'égalera jamais les fourmis
Sur cette solidarité sublime.

Une petite chenille, sur l'arbre de Papi,
Dans son grand jardin si joli.
Ma chenille de compagnie, mon amie,
Qui, un beau matin, est partie,
Laissant un cocon blanc et vide.

J'en courus dans les bras de Patrick
Pour lui annoncer la tragédie.
D'un sourire réconfortant, il me dit :
« Sois juste patient, et tu seras ravie. »

Quelques jours plus tard, la vie me sourit,
En me rendant mon amie, ma chenille.
Devrais-je toujours l'appeler ainsi,
Maintenant qu'elle est un joli papillon de nuit ?

La vie est si jolie si tu prends le temps de la vivre.
Chaque seconde, chaque journée, chaque année
Sont de beaux souvenirs.
Alors moi, j'en profite tant que j'y suis.`,
  },
  {
    title: "Dernier regard",
    category: "Amour",
    content: `Un soleil radieux, des nuages denses
Une journée banale pour toi je pense
Un regard volé timide et intense
Que tu ne sus contempler dans l'ignorance

Je te vis une dernière fois sans marquer ma présence
J'eus envie de te parler, de te voir rayonnante
Un soulagement j'aurais eu car ton absence
Me laisse un goût d'amertume pas une délivrance

Un pas je fis pour briser ce silence
Avec ce sourire qui me mène à la dépendance
Toi et moi tels une évidence
Que j'hélas vis seul avec assurance

Mais je ne fis rien d'extravagant
Jouant la carte de l'indifférence
Rêvant de pouvoir remonter le temps
Avant que ce lien ne devienne souffrance

Des adieux, je ne les aimerais jamais
Comme toi que je ne saurais oublier
Je dirais au-revoir au lieu d'adieu
Car tu ne saurais disparaître de mes souvenirs heureux`,
  },
  {
    title: "Poème",
    category: "Réflexion",
    content: `Un soir tragique, un moi dépressif,
Tel une étoile vidée de sa lumière,
Je me perdis dans l'obscurité,
Mon cœur devenu sable, mon âme réduite en cendres.
Je divaguais dans le noir, criant mon désespoir au vent.

Incapable de contenir toute cette tristesse en moi,
Accumulée pendant des années, je crois.
Tel une fourmi portant un éléphant,
Elle doublait de poids à chaque déception,
Faisant de moi le spectateur de mon propre effondrement.

Sans savoir comment, ni même pourquoi, j'écrivis.
Ni aveu, ni testament ; seulement des pensées refoulées,
Parfois rythmées, souvent brouillonnes,
Mais ces vers, si narratifs,
Me soulageaient d'une étrange façon.

Je me mis à comprendre ces mots qui me comprenaient.
Ces étranges mots couchés sur une feuille de papier
Me procuraient une liberté incomparable.
On appelait cela des poèmes ;
Et sans m'en rendre compte, je devenais poète.

Chaque émotion un peu trop intense
Se laissait capturer par quelques mots libérateurs.
Alors j'écris.
J'écris pour moi, pour toi, pour eux.
Car un poème n'est pas qu'une suite de jolis mots,
Mais l'expression d'une âme,
La mélodie silencieuse de la vie.`,
  },
  {
    title: "Futurs Illusoire",
    category: "Amour",
    content: `Chaque matin, tu te lèves un peu plus tôt que moi,
Mais chaque soir, je veille encore pour toi.
Ces mots doux au réveil m'envahissaient de joie,
Toutes ces discussions sans importance, parfois.

La douceur de ta peau à chacun de mes baisers,
La chaleur de ton corps blottie dans mes câlins,
Ce sourire sur tes lèvres quand on jouait sans compter,
Tes blagues les plus stupides me faisaient rigoler.

Nos balades en ville, nos sorties improvisées,
Tu brillais si fort que nos glaces fondaient.
À ton éclat, même le soleil baissait les yeux,
Comme s'il n'avait plus sa place sous les cieux.

Ces petits instants que l'on croit insignifiants,
Ces habitudes bâties au fil des mois...
Ai-je une imagination débordante, absurde, vraiment ?
Non... juste un futur qui n'existait que dans mes pensées.

Car je ne sentirai jamais la douceur de ta peau,
Je ne connaîtrai jamais la chaleur de tes mains.
Tous ces souvenirs n'étaient que des lendemains trop beaux,
Des rêves habillés en quotidien.

Hélas, ils ne prendront jamais vie,
Dans ce monde où tu ne m'a pas choisi.`,
  },
  {
    title: "J'aurais pu te dire que je t'aime",
    category: "Amour",
    content: `J'aurais pu te dire que je t'aime,
Mais je préfère te dire ceci :

Quand je te vois, quand je te parle,
Mon cœur s'emballe, mes barrières se cassent.

Quand je t'enlace, quand je t'embrasse,
Les lumières s'éteignent... et je vois dans le noir.

Grâce à cette lueur, grâce à cette flamme,
Qui me dévore en douceur, telle une fleur qui se fane.

Et si cette flamme devenait trop forte,
Je deviendrais cendre au rivage de ton port.`,
  },
  {
    title: "Tangible Abstrait",
    category: "Amour",
    content: `Du tangible à l'abstrait,
Tu n'es plus une présence mais un souvenir.
Mon cœur s'emballe, pupilles dilatées,
Au seul souvenir de ton sourire.

Où pourrais-je me perdre
Si ce n'est au fond de ton regard ?
Quelle mélodie vouloir entendre
Si ce n'est l'écho de ta voix ?
Et quelle raison d'exister
Si ce n'est celle d'être près de toi ?

Le jour se fait nuit sans mon soleil.
Pourquoi me laisser seul dans les ténèbres ?
Pourtant ce n'est pas si mal, au fond,
Puisque c'est là que je te retrouve : dans mes rêves.

C'est là que je deviens jaloux
De ceux qui ont le droit de te serrer,
De ceux qui ont la chance de te côtoyer.

Je rêvais d'être le héros
Dans le grand film de ta vie.
Mais j'ai échoué au casting, c'est ainsi.
C'est difficile à dire, pourtant :
Te retenir reviendrait à capturer les rayons du soleil.`,
  },
];

async function main() {
  const client = await pool.connect();
  try {
    console.log("Seeding admin account...");
    const passwordHash = await bcrypt.hash("25mai2008", 10);
    await client.query(
      `INSERT INTO admins (username, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash`,
      ["pmpd", passwordHash]
    );

    console.log("Seeding poems...");
    for (const poem of poems) {
      const slug = slugify(poem.title);
      const excerpt = excerptOf(poem.content);
      await client.query(
        `INSERT INTO poems (slug, title, content, excerpt, category, published, featured)
         VALUES ($1, $2, $3, $4, $5, true, $6)
         ON CONFLICT (slug) DO UPDATE SET
           title = EXCLUDED.title,
           content = EXCLUDED.content,
           excerpt = EXCLUDED.excerpt,
           category = EXCLUDED.category,
           featured = EXCLUDED.featured`,
        [slug, poem.title, poem.content, excerpt, poem.category, !!poem.featured]
      );
    }

    console.log(`Seed complete: ${poems.length} poems, 1 admin.`);
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
