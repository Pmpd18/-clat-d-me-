import "server-only";
import { db } from "@/db";
import { poems } from "@/db/schema";
import { and, desc, eq, ne, sql } from "drizzle-orm";

export type Poem = typeof poems.$inferSelect;

export function slugify(title: string): string {
  return title
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export function makeExcerpt(content: string): string {
  const firstLines = content.split("\n").filter(Boolean).slice(0, 2).join(" ");
  return firstLines.length > 160 ? firstLines.slice(0, 157) + "..." : firstLines;
}

export async function getPublishedPoems() {
  return db
    .select()
    .from(poems)
    .where(eq(poems.published, true))
    .orderBy(desc(poems.createdAt));
}

export async function getFeaturedPoems(limit = 3) {
  return db
    .select()
    .from(poems)
    .where(and(eq(poems.published, true), eq(poems.featured, true)))
    .orderBy(desc(poems.createdAt))
    .limit(limit);
}

export async function getPoemBySlug(slug: string) {
  const rows = await db.select().from(poems).where(eq(poems.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getAdjacentPoems(currentId: number, createdAt: Date) {
  const [prev] = await db
    .select()
    .from(poems)
    .where(and(eq(poems.published, true), sql`${poems.createdAt} < ${createdAt}`, ne(poems.id, currentId)))
    .orderBy(desc(poems.createdAt))
    .limit(1);

  const [next] = await db
    .select()
    .from(poems)
    .where(and(eq(poems.published, true), sql`${poems.createdAt} > ${createdAt}`, ne(poems.id, currentId)))
    .orderBy(poems.createdAt)
    .limit(1);

  return { prev: prev ?? null, next: next ?? null };
}

export async function incrementViews(id: number) {
  await db
    .update(poems)
    .set({ views: sql`${poems.views} + 1` })
    .where(eq(poems.id, id));
}

export async function getAllPoemsAdmin() {
  return db.select().from(poems).orderBy(desc(poems.createdAt));
}

export async function getPoemById(id: number) {
  const rows = await db.select().from(poems).where(eq(poems.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function getCategories() {
  const rows = await db
    .selectDistinct({ category: poems.category })
    .from(poems)
    .where(eq(poems.published, true));
  return rows.map((r) => r.category).sort();
}
