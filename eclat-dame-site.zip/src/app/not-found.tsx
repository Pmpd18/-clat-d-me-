import Link from "next/link";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#faf6ee] px-6 text-center">
      <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">Erreur 404</p>
      <h1 className="mt-4 font-display text-4xl font-bold text-[#16131c] sm:text-5xl">
        Ce vers n&apos;existe pas
      </h1>
      <p className="mt-4 max-w-md font-poem text-lg italic text-stone-600">
        La page que vous cherchez s&apos;est perdue quelque part entre deux strophes.
      </p>
      <Link
        href="/"
        className="mt-10 rounded-full bg-[#4a1f36] px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-white transition hover:bg-[#3a1729]"
      >
        Retour à l&apos;accueil
      </Link>
    </main>
  );
}
