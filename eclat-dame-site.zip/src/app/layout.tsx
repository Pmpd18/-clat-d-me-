import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Playfair_Display, Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "600", "700", "800", "900"],
});

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  variable: "--font-poem",
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: {
    default: "Éclat d'âme — Recueil de poèmes",
    template: "%s — Éclat d'âme",
  },
  description:
    "Un recueil de poèmes intimes sur l'amour, le doute, la mélancolie et la vie, écrits par Éclat d'âme.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body
        className={`${playfair.variable} ${cormorant.variable} ${inter.variable} bg-[#0f0d13] font-[family-name:var(--font-body)] text-stone-800 antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
