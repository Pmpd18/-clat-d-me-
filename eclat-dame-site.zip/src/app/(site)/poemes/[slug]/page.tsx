import Link from "next/link";
import { notFound } from "next/navigation";
import { getAdjacentPoems, getPoemBySlug, incrementViews } from "@/lib/poems";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const poem = await getPoemBySlug(slug);
  if (!poem) return {};
  return {
    title: poem.title,
    description: poem.excerpt ?? undefined,
  };
}

export default async function PoemPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const poem = await getPoemBySlug(slug);

  if (!poem || !poem.published) {
    notFound();
  }

  incrementViews(poem.id).catch(() => {});

  const { prev, next } = await getAdjacentPoems(poem.id, poem.createdAt);

  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <Link href="/poemes" className="font-body text-sm text-[#4a1f36] hover:text-[#c9a15a]">
        ← Retour au recueil
      </Link>

      <article className="mt-8">
        <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">
          {poem.category}
        </p>
        <h1 className="mt-3 font-display text-3xl font-bold leading-tight text-[#16131c] sm:text-5xl">
          {poem.title}
        </h1>
        <p className="mt-4 font-body text-xs uppercase tracking-[0.15em] text-stone-400">
          Publié le{" "}
          {new Intl.DateTimeFormat("fr-FR", { dateStyle: "long" }).format(poem.createdAt)}
        </p>

        <div className="poem-text mt-10 rounded-3xl border border-stone-200 bg-white px-8 py-12 text-lg leading-[2] text-[#16131c] shadow-sm sm:px-14 sm:text-xl">
          {poem.content}
        </div>
      </article>

      <div className="mt-14 grid gap-4 border-t border-stone-200 pt-10 sm:grid-cols-2">
        {prev ? (
          <Link
            href={`/poemes/${prev.slug}`}
            className="rounded-xl border border-stone-200 p-5 transition hover:border-[#c9a15a]"
          >
            <p className="font-body text-xs uppercase tracking-[0.1em] text-stone-400">
              Poème précédent
            </p>
            <p className="mt-2 font-display font-semibold text-[#16131c]">{prev.title}</p>
          </Link>
        ) : (
          <div />
        )}
        {next ? (
          <Link
            href={`/poemes/${next.slug}`}
            className="rounded-xl border border-stone-200 p-5 text-right transition hover:border-[#c9a15a]"
          >
            <p className="font-body text-xs uppercase tracking-[0.1em] text-stone-400">
              Poème suivant
            </p>
            <p className="mt-2 font-display font-semibold text-[#16131c]">{next.title}</p>
          </Link>
        ) : (
          <div />
        )}
      </div>
    </main>
  );
}
