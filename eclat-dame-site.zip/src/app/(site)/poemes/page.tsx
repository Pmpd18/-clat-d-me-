import Link from "next/link";
import { getCategories, getPublishedPoems } from "@/lib/poems";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Tous les poèmes",
  description: "Découvrez l'intégralité du recueil de poèmes d'Éclat d'âme.",
};

export default async function PoemesPage({
  searchParams,
}: {
  searchParams: Promise<{ categorie?: string }>;
}) {
  const { categorie } = await searchParams;
  const [poems, categories] = await Promise.all([getPublishedPoems(), getCategories()]);

  const filtered = categorie
    ? poems.filter((p) => p.category.toLowerCase() === categorie.toLowerCase())
    : poems;

  return (
    <main className="mx-auto max-w-6xl px-6 py-20">
      <div className="text-center">
        <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">
          Le recueil
        </p>
        <h1 className="mt-3 font-display text-4xl font-bold text-[#16131c] sm:text-5xl">
          Tous les poèmes
        </h1>
        <p className="mx-auto mt-4 max-w-xl font-poem text-lg italic text-stone-600">
          {poems.length} textes écrits au fil des saisons, entre amour, doute et lumière.
        </p>
      </div>

      <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
        <Link
          href="/poemes"
          className={`rounded-full px-4 py-2 font-body text-xs uppercase tracking-[0.1em] transition ${
            !categorie
              ? "bg-[#4a1f36] text-white"
              : "border border-stone-300 text-stone-600 hover:border-[#4a1f36]"
          }`}
        >
          Tous
        </Link>
        {categories.map((cat) => (
          <Link
            key={cat}
            href={`/poemes?categorie=${encodeURIComponent(cat)}`}
            className={`rounded-full px-4 py-2 font-body text-xs uppercase tracking-[0.1em] transition ${
              categorie?.toLowerCase() === cat.toLowerCase()
                ? "bg-[#4a1f36] text-white"
                : "border border-stone-300 text-stone-600 hover:border-[#4a1f36]"
            }`}
          >
            {cat}
          </Link>
        ))}
      </div>

      <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((poem) => (
          <Link
            key={poem.id}
            href={`/poemes/${poem.slug}`}
            className="group flex flex-col rounded-2xl border border-stone-200 bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
          >
            <span className="font-body text-xs uppercase tracking-[0.16em] text-[#c9a15a]">
              {poem.category}
            </span>
            <h2 className="mt-3 font-display text-xl font-semibold text-[#16131c] group-hover:text-[#4a1f36]">
              {poem.title}
            </h2>
            <p className="mt-4 flex-1 font-poem text-[15px] italic leading-relaxed text-stone-600">
              {poem.excerpt}
            </p>
            <span className="mt-6 font-body text-sm font-medium text-[#4a1f36] gold-underline w-fit">
              Lire le poème
            </span>
          </Link>
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="mt-16 text-center font-poem italic text-stone-500">
          Aucun poème dans cette catégorie pour le moment.
        </p>
      )}
    </main>
  );
}
