export const metadata = {
  title: "À propos",
  description: "À propos d'Éclat d'âme, auteur de ce recueil de poèmes.",
};

export default function AboutPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">
        À propos
      </p>
      <h1 className="mt-3 font-display text-4xl font-bold text-[#16131c] sm:text-5xl">
        Derrière les mots
      </h1>

      <div className="mt-10 space-y-6 font-poem text-lg italic leading-relaxed text-stone-700">
        <p>
          Éclat d&apos;âme écrit depuis toujours pour comprendre ce que le cœur n&apos;arrive pas à dire à
          voix haute. Chaque poème est né d&apos;un instant vécu : un regard, un silence, une
          absence, une joie discrète.
        </p>
        <p>
          Ce recueil rassemble des textes sur l&apos;amour naissant ou impossible, le doute qui
          ronge, la mélancolie qui pèse, et cette lumière obstinée qui revient toujours après
          l&apos;orage. Ce sont des poèmes sincères, écrits sans artifice, pour soi d&apos;abord,
          puis pour celles et ceux qui s&apos;y reconnaîtront.
        </p>
        <p>
          « Un poème n&apos;est pas qu&apos;une suite de jolis mots, mais l&apos;expression
          d&apos;une âme, la mélodie silencieuse de la vie. »
        </p>
      </div>

      <div className="mt-14 rounded-2xl border border-stone-200 bg-white p-8">
        <h2 className="font-display text-xl font-semibold text-[#16131c]">
          Pourquoi ce site ?
        </h2>
        <p className="mt-4 font-body text-[15px] leading-relaxed text-stone-600">
          Ce site a été créé pour rassembler et partager l&apos;ensemble de ces poèmes dans un
          espace calme et soigné, à l&apos;image des textes eux-mêmes. Vous pouvez parcourir le
          recueil complet, lire chaque poème dans son intégralité, et laisser un message via la
          page contact.
        </p>
      </div>
    </main>
  );
}
