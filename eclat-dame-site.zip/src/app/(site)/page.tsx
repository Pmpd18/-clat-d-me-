import Link from "next/link";
import { getFeaturedPoems, getPublishedPoems } from "@/lib/poems";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [featured, all] = await Promise.all([getFeaturedPoems(3), getPublishedPoems()]);
  const recent = all.slice(0, 3);
  const totalPoems = all.length;

  return (
    <main>
      <section className="relative overflow-hidden bg-[#16131c] text-white">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -left-24 top-10 h-72 w-72 rounded-full bg-[#c9a15a]/10 blur-3xl" />
          <div className="absolute -right-16 bottom-0 h-80 w-80 rounded-full bg-[#4a1f36]/40 blur-3xl" />
        </div>
        <div className="relative mx-auto flex max-w-6xl flex-col items-center px-6 py-28 text-center sm:py-36">
          <p className="font-body text-xs uppercase tracking-[0.35em] text-[#e7cd9a]">
            Recueil intime
          </p>
          <h1 className="mt-6 max-w-3xl font-display text-[clamp(2.4rem,6vw,4.2rem)] font-bold leading-[1.1]">
            Des mots pour dire<br />ce que le cœur murmure
          </h1>
          <p className="mt-6 max-w-xl font-poem text-lg italic leading-relaxed text-white/70">
            Éclat d&apos;âme écrit l&apos;amour, le doute, la mélancolie et l&apos;espoir avec la sincérité
            d&apos;une âme qui n&apos;a jamais cessé de sentir.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <Link
              href="/poemes"
              className="rounded-full bg-[#c9a15a] px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-[#16131c] transition hover:bg-[#e7cd9a]"
            >
              Lire les poèmes
            </Link>
            <Link
              href="/a-propos"
              className="rounded-full border border-white/25 px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-white transition hover:border-[#e7cd9a] hover:text-[#e7cd9a]"
            >
              À propos de l&apos;auteur
            </Link>
          </div>
          <p className="mt-12 font-body text-xs uppercase tracking-[0.2em] text-white/40">
            {totalPoems} poèmes publiés
          </p>
        </div>
      </section>

      {featured.length > 0 && (
        <section className="paper-texture mx-auto max-w-6xl px-6 py-24">
          <div className="mb-12 text-center">
            <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">
              À la une
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold text-[#16131c] sm:text-4xl">
              Poèmes à découvrir
            </h2>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {featured.map((poem) => (
              <Link
                key={poem.id}
                href={`/poemes/${poem.slug}`}
                className="group flex flex-col rounded-2xl border border-stone-200 bg-white p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <span className="font-body text-xs uppercase tracking-[0.16em] text-[#c9a15a]">
                  {poem.category}
                </span>
                <h3 className="mt-3 font-display text-xl font-semibold text-[#16131c] group-hover:text-[#4a1f36]">
                  {poem.title}
                </h3>
                <p className="mt-4 flex-1 font-poem text-[15px] italic leading-relaxed text-stone-600">
                  {poem.excerpt}
                </p>
                <span className="mt-6 font-body text-sm font-medium text-[#4a1f36] gold-underline w-fit">
                  Lire le poème
                </span>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="bg-[#f2ead9] py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-12 flex flex-col items-center text-center">
            <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">
              Derniers écrits
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold text-[#16131c] sm:text-4xl">
              Les poèmes les plus récents
            </h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {recent.map((poem) => (
              <Link
                key={poem.id}
                href={`/poemes/${poem.slug}`}
                className="rounded-xl border border-[#e4d6b8] bg-[#faf6ee] p-6 transition hover:border-[#c9a15a]"
              >
                <h3 className="font-display text-lg font-semibold text-[#16131c]">{poem.title}</h3>
                <p className="mt-2 line-clamp-3 font-poem text-sm italic text-stone-600">
                  {poem.excerpt}
                </p>
              </Link>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link
              href="/poemes"
              className="inline-block rounded-full border border-[#4a1f36] px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-[#4a1f36] transition hover:bg-[#4a1f36] hover:text-white"
            >
              Voir tout le recueil
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-6 py-24 text-center">
        <p className="font-poem text-2xl italic leading-relaxed text-[#4a1f36] sm:text-3xl">
          « J&apos;écris pour moi, pour toi, pour eux. Car un poème n&apos;est pas qu&apos;une
          suite de jolis mots, mais l&apos;expression d&apos;une âme. »
        </p>
        <p className="mt-6 font-body text-sm uppercase tracking-[0.2em] text-[#c9a15a]">
          — Éclat d&apos;âme
        </p>
      </section>
    </main>
  );
}
