import { ContactForm } from "./contact-form";

export const metadata = {
  title: "Contact",
  description: "Contactez Éclat d'âme à propos de ses poèmes.",
};

export default function ContactPage() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-20">
      <p className="font-body text-xs uppercase tracking-[0.3em] text-[#c9a15a]">Contact</p>
      <h1 className="mt-3 font-display text-4xl font-bold text-[#16131c] sm:text-5xl">
        Laisser un message
      </h1>
      <p className="mt-4 font-poem text-lg italic text-stone-600">
        Un mot, une émotion, une question à propos d&apos;un poème ? Écrivez-moi.
      </p>

      <ContactForm />
    </main>
  );
}
