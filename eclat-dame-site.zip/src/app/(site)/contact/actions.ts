"use server";

import { db } from "@/db";
import { messages } from "@/db/schema";

export type ContactState = {
  status: "idle" | "success" | "error";
  message: string;
};

export async function sendMessage(
  _prevState: ContactState,
  formData: FormData
): Promise<ContactState> {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim();
  const content = String(formData.get("content") ?? "").trim();

  if (!name || !email || !content) {
    return { status: "error", message: "Merci de remplir tous les champs." };
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return { status: "error", message: "Merci de renseigner une adresse email valide." };
  }

  if (content.length > 4000) {
    return { status: "error", message: "Votre message est trop long." };
  }

  try {
    await db.insert(messages).values({ name, email, content });
    return {
      status: "success",
      message: "Votre message a bien été envoyé. Merci de l'avoir partagé.",
    };
  } catch (error) {
    console.error(error);
    return {
      status: "error",
      message: "Une erreur est survenue, merci de réessayer plus tard.",
    };
  }
}
