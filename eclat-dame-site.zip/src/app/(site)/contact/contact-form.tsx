"use client";

import { useActionState } from "react";
import { sendMessage, type ContactState } from "./actions";

const initialState: ContactState = { status: "idle", message: "" };

export function ContactForm() {
  const [state, formAction, pending] = useActionState(sendMessage, initialState);

  return (
    <form action={formAction} className="mt-10 space-y-6">
      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="font-body text-xs uppercase tracking-[0.14em] text-stone-500">
            Nom
          </label>
          <input
            id="name"
            name="name"
            required
            maxLength={150}
            className="mt-2 w-full rounded-lg border border-stone-300 bg-white px-4 py-3 font-body text-sm text-stone-800 outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
            placeholder="Votre nom"
          />
        </div>
        <div>
          <label htmlFor="email" className="font-body text-xs uppercase tracking-[0.14em] text-stone-500">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            maxLength={200}
            className="mt-2 w-full rounded-lg border border-stone-300 bg-white px-4 py-3 font-body text-sm text-stone-800 outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
            placeholder="vous@exemple.com"
          />
        </div>
      </div>

      <div>
        <label htmlFor="content" className="font-body text-xs uppercase tracking-[0.14em] text-stone-500">
          Message
        </label>
        <textarea
          id="content"
          name="content"
          required
          rows={6}
          maxLength={4000}
          className="mt-2 w-full rounded-lg border border-stone-300 bg-white px-4 py-3 font-body text-sm text-stone-800 outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
          placeholder="Votre message..."
        />
      </div>

      {state.status !== "idle" && (
        <p
          className={`font-body text-sm ${
            state.status === "success" ? "text-emerald-700" : "text-red-700"
          }`}
        >
          {state.message}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-[#4a1f36] px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-white transition hover:bg-[#3a1729] disabled:opacity-60"
      >
        {pending ? "Envoi en cours..." : "Envoyer le message"}
      </button>
    </form>
  );
}
