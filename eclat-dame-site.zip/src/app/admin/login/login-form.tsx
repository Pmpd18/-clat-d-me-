"use client";

import { useActionState } from "react";
import { loginAction, type LoginState } from "./actions";

const initialState: LoginState = { status: "idle", message: "" };

export function LoginForm() {
  const [state, formAction, pending] = useActionState(loginAction, initialState);

  return (
    <form action={formAction} className="mt-8 space-y-5">
      <div>
        <label htmlFor="username" className="font-body text-xs uppercase tracking-[0.14em] text-white/50">
          Identifiant
        </label>
        <input
          id="username"
          name="username"
          required
          autoComplete="username"
          className="mt-2 w-full rounded-lg border border-white/15 bg-white/5 px-4 py-3 font-body text-sm text-white outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
          placeholder="pmpd"
        />
      </div>
      <div>
        <label htmlFor="password" className="font-body text-xs uppercase tracking-[0.14em] text-white/50">
          Mot de passe
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="mt-2 w-full rounded-lg border border-white/15 bg-white/5 px-4 py-3 font-body text-sm text-white outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
          placeholder="••••••••"
        />
      </div>

      {state.status === "error" && (
        <p className="font-body text-sm text-red-400">{state.message}</p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="w-full rounded-full bg-[#c9a15a] px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-[#16131c] transition hover:bg-[#e7cd9a] disabled:opacity-60"
      >
        {pending ? "Connexion..." : "Se connecter"}
      </button>
    </form>
  );
}
