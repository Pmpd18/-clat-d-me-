"use server";

import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import { admins } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSessionToken, setSessionCookie } from "@/lib/auth";

export type LoginState = {
  status: "idle" | "error";
  message: string;
};

export async function loginAction(
  _prevState: LoginState,
  formData: FormData
): Promise<LoginState> {
  const username = String(formData.get("username") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  if (!username || !password) {
    return { status: "error", message: "Merci de renseigner l'identifiant et le mot de passe." };
  }

  const rows = await db.select().from(admins).where(eq(admins.username, username)).limit(1);
  const admin = rows[0];

  if (!admin) {
    return { status: "error", message: "Identifiants incorrects." };
  }

  const valid = await bcrypt.compare(password, admin.passwordHash);
  if (!valid) {
    return { status: "error", message: "Identifiants incorrects." };
  }

  const token = await createSessionToken(admin.username);
  await setSessionCookie(token);

  redirect("/admin");
}
