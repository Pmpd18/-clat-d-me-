import Link from "next/link";
import { LoginForm } from "./login-form";

export const metadata = {
  title: "Connexion administrateur",
};

export default function AdminLoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-[#16131c] px-6 py-16">
      <div className="w-full max-w-sm">
        <div className="text-center">
          <Link href="/" className="font-display text-2xl font-bold text-[#e7cd9a]">
            Éclat d&apos;âme
          </Link>
          <h1 className="mt-6 font-display text-2xl font-semibold text-white">
            Espace administrateur
          </h1>
          <p className="mt-2 font-body text-sm text-white/50">
            Connectez-vous pour gérer le recueil de poèmes.
          </p>
        </div>

        <LoginForm />

        <p className="mt-8 text-center">
          <Link href="/" className="font-body text-xs uppercase tracking-[0.14em] text-white/40 hover:text-[#e7cd9a]">
            ← Retour au site
          </Link>
        </p>
      </div>
    </main>
  );
}
