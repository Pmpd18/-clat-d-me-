import Link from "next/link";
import { db } from "@/db";
import { poems, messages } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminHomePage() {
  const [poemStats] = await db
    .select({
      total: sql<number>`count(*)`,
      published: sql<number>`count(*) filter (where ${poems.published} = true)`,
      views: sql<number>`coalesce(sum(${poems.views}), 0)`,
    })
    .from(poems);

  const [messageStats] = await db
    .select({
      total: sql<number>`count(*)`,
      unread: sql<number>`count(*) filter (where ${messages.read} = false)`,
    })
    .from(messages);

  const recentPoems = await db.select().from(poems).orderBy(desc(poems.createdAt)).limit(5);
  const recentMessages = await db
    .select()
    .from(messages)
    .where(eq(messages.read, false))
    .orderBy(desc(messages.createdAt))
    .limit(5);

  const cards = [
    { label: "Poèmes publiés", value: `${poemStats?.published ?? 0} / ${poemStats?.total ?? 0}` },
    { label: "Vues cumulées", value: poemStats?.views ?? 0 },
    { label: "Messages non lus", value: `${messageStats?.unread ?? 0} / ${messageStats?.total ?? 0}` },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-bold text-[#16131c]">Vue d&apos;ensemble</h1>
        <Link
          href="/admin/poemes/nouveau"
          className="rounded-full bg-[#4a1f36] px-6 py-2.5 font-body text-sm font-semibold uppercase tracking-[0.1em] text-white hover:bg-[#3a1729]"
        >
          + Nouveau poème
        </Link>
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-3">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-stone-200 bg-white p-6">
            <p className="font-body text-xs uppercase tracking-[0.14em] text-stone-400">
              {card.label}
            </p>
            <p className="mt-2 font-display text-3xl font-bold text-[#16131c]">{card.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-2">
        <div className="rounded-2xl border border-stone-200 bg-white p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-[#16131c]">
              Poèmes récents
            </h2>
            <Link href="/admin/poemes" className="font-body text-xs uppercase tracking-[0.1em] text-[#4a1f36]">
              Tout voir
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-stone-100">
            {recentPoems.map((poem) => (
              <li key={poem.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="font-body text-sm font-medium text-[#16131c]">{poem.title}</p>
                  <p className="font-body text-xs text-stone-400">{poem.category}</p>
                </div>
                <Link
                  href={`/admin/poemes/${poem.id}`}
                  className="font-body text-xs uppercase tracking-[0.1em] text-[#4a1f36] hover:underline"
                >
                  Modifier
                </Link>
              </li>
            ))}
            {recentPoems.length === 0 && (
              <p className="py-4 font-body text-sm text-stone-400">Aucun poème pour le moment.</p>
            )}
          </ul>
        </div>

        <div className="rounded-2xl border border-stone-200 bg-white p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-[#16131c]">
              Messages non lus
            </h2>
            <Link href="/admin/messages" className="font-body text-xs uppercase tracking-[0.1em] text-[#4a1f36]">
              Tout voir
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-stone-100">
            {recentMessages.map((message) => (
              <li key={message.id} className="py-3">
                <p className="font-body text-sm font-medium text-[#16131c]">{message.name}</p>
                <p className="font-body text-xs text-stone-400">{message.email}</p>
                <p className="mt-1 line-clamp-2 font-body text-sm text-stone-600">
                  {message.content}
                </p>
              </li>
            ))}
            {recentMessages.length === 0 && (
              <p className="py-4 font-body text-sm text-stone-400">
                Aucun nouveau message.
              </p>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
