"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { poems, messages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { clearSessionCookie, getSession } from "@/lib/auth";
import { makeExcerpt, slugify } from "@/lib/poems";

async function requireAuth() {
  const session = await getSession();
  if (!session) {
    redirect("/admin/login");
  }
  return session;
}

export type PoemFormState = {
  status: "idle" | "error";
  message: string;
};

async function uniqueSlug(title: string, ignoreId?: number): Promise<string> {
  const base = slugify(title) || "poeme";
  let slug = base;
  let counter = 2;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const rows = await db.select({ id: poems.id }).from(poems).where(eq(poems.slug, slug)).limit(1);
    const existing = rows[0];
    if (!existing || existing.id === ignoreId) {
      return slug;
    }
    slug = `${base}-${counter}`;
    counter += 1;
  }
}

export async function createPoemAction(
  _prevState: PoemFormState,
  formData: FormData
): Promise<PoemFormState> {
  await requireAuth();

  const title = String(formData.get("title") ?? "").trim();
  const content = String(formData.get("content") ?? "").trim();
  const category = String(formData.get("category") ?? "Amour").trim() || "Amour";
  const published = formData.get("published") === "on";
  const featured = formData.get("featured") === "on";

  if (!title || !content) {
    return { status: "error", message: "Le titre et le contenu sont obligatoires." };
  }

  const slug = await uniqueSlug(title);
  const excerpt = makeExcerpt(content);

  await db.insert(poems).values({ slug, title, content, excerpt, category, published, featured });

  revalidatePath("/poemes");
  revalidatePath("/");
  revalidatePath("/admin/poemes");
  redirect("/admin/poemes");
}

export async function updatePoemAction(
  id: number,
  _prevState: PoemFormState,
  formData: FormData
): Promise<PoemFormState> {
  await requireAuth();

  const title = String(formData.get("title") ?? "").trim();
  const content = String(formData.get("content") ?? "").trim();
  const category = String(formData.get("category") ?? "Amour").trim() || "Amour";
  const published = formData.get("published") === "on";
  const featured = formData.get("featured") === "on";

  if (!title || !content) {
    return { status: "error", message: "Le titre et le contenu sont obligatoires." };
  }

  const current = await db.select().from(poems).where(eq(poems.id, id)).limit(1);
  if (!current[0]) {
    return { status: "error", message: "Poème introuvable." };
  }

  let slug = current[0].slug;
  if (current[0].title !== title) {
    slug = await uniqueSlug(title, id);
  }

  const excerpt = makeExcerpt(content);

  await db
    .update(poems)
    .set({ title, content, excerpt, category, published, featured, slug, updatedAt: new Date() })
    .where(eq(poems.id, id));

  revalidatePath("/poemes");
  revalidatePath("/");
  revalidatePath(`/poemes/${slug}`);
  revalidatePath("/admin/poemes");
  redirect("/admin/poemes");
}

export async function deletePoemAction(id: number): Promise<void> {
  await requireAuth();
  await db.delete(poems).where(eq(poems.id, id));
  revalidatePath("/poemes");
  revalidatePath("/");
  revalidatePath("/admin/poemes");
}

export async function togglePublishedAction(id: number, published: boolean): Promise<void> {
  await requireAuth();
  await db.update(poems).set({ published, updatedAt: new Date() }).where(eq(poems.id, id));
  revalidatePath("/poemes");
  revalidatePath("/");
  revalidatePath("/admin/poemes");
}

export async function toggleFeaturedAction(id: number, featured: boolean): Promise<void> {
  await requireAuth();
  await db.update(poems).set({ featured, updatedAt: new Date() }).where(eq(poems.id, id));
  revalidatePath("/poemes");
  revalidatePath("/");
  revalidatePath("/admin/poemes");
}

export async function markMessageReadAction(id: number, read: boolean): Promise<void> {
  await requireAuth();
  await db.update(messages).set({ read }).where(eq(messages.id, id));
  revalidatePath("/admin/messages");
}

export async function deleteMessageAction(id: number): Promise<void> {
  await requireAuth();
  await db.delete(messages).where(eq(messages.id, id));
  revalidatePath("/admin/messages");
}

export async function logoutAction(): Promise<void> {
  await clearSessionCookie();
  redirect("/admin/login");
}
