import { PoemForm } from "../poem-form";
import { createPoemAction } from "../../actions";

export const metadata = {
  title: "Nouveau poème",
};

export default function NewPoemPage() {
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-3xl font-bold text-[#16131c]">Nouveau poème</h1>
      <p className="mt-2 font-body text-sm text-stone-500">
        Ajoutez un nouveau texte au recueil.
      </p>

      <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-8">
        <PoemForm action={createPoemAction} submitLabel="Publier le poème" />
      </div>
    </div>
  );
}
