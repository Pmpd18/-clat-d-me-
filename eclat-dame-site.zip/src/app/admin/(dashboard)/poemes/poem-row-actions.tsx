"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  deletePoemAction,
  togglePublishedAction,
  toggleFeaturedAction,
} from "../actions";

export function PoemRowActions({
  id,
  published,
  featured,
}: {
  id: number;
  published: boolean;
  featured: boolean;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        disabled={isPending}
        onClick={() => startTransition(async () => {
          await togglePublishedAction(id, !published);
          router.refresh();
        })}
        className={`rounded-full px-3 py-1 font-body text-xs uppercase tracking-[0.08em] ${
          published
            ? "bg-emerald-100 text-emerald-700"
            : "bg-stone-200 text-stone-600"
        }`}
      >
        {published ? "Publié" : "Brouillon"}
      </button>
      <button
        type="button"
        disabled={isPending}
        onClick={() => startTransition(async () => {
          await toggleFeaturedAction(id, !featured);
          router.refresh();
        })}
        className={`rounded-full px-3 py-1 font-body text-xs uppercase tracking-[0.08em] ${
          featured ? "bg-[#e7cd9a] text-[#4a1f36]" : "bg-stone-100 text-stone-500"
        }`}
      >
        {featured ? "★ À la une" : "☆ Mettre en avant"}
      </button>
      <button
        type="button"
        disabled={isPending}
        onClick={() => {
          if (confirm("Supprimer définitivement ce poème ?")) {
            startTransition(async () => {
              await deletePoemAction(id);
              router.refresh();
            });
          }
        }}
        className="rounded-full bg-red-50 px-3 py-1 font-body text-xs uppercase tracking-[0.08em] text-red-600 hover:bg-red-100"
      >
        Supprimer
      </button>
    </div>
  );
}
