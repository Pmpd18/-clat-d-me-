"use client";

import { useActionState } from "react";
import type { PoemFormState } from "../actions";

const CATEGORIES = ["Amour", "Mélancolie", "Réflexion", "Vie", "Admiration"];

const initialState: PoemFormState = { status: "idle", message: "" };

export function PoemForm({
  action,
  defaultValues,
  submitLabel,
}: {
  action: (prevState: PoemFormState, formData: FormData) => Promise<PoemFormState>;
  defaultValues?: {
    title: string;
    content: string;
    category: string;
    published: boolean;
    featured: boolean;
  };
  submitLabel: string;
}) {
  const [state, formAction, pending] = useActionState(action, initialState);

  return (
    <form action={formAction} className="space-y-6">
      <div>
        <label htmlFor="title" className="font-body text-xs uppercase tracking-[0.14em] text-stone-500">
          Titre
        </label>
        <input
          id="title"
          name="title"
          required
          defaultValue={defaultValues?.title}
          className="mt-2 w-full rounded-lg border border-stone-300 bg-white px-4 py-3 font-display text-lg text-stone-800 outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
          placeholder="Titre du poème"
        />
      </div>

      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="category" className="font-body text-xs uppercase tracking-[0.14em] text-stone-500">
            Catégorie
          </label>
          <select
            id="category"
            name="category"
            defaultValue={defaultValues?.category ?? "Amour"}
            className="mt-2 w-full rounded-lg border border-stone-300 bg-white px-4 py-3 font-body text-sm text-stone-800 outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-end gap-6">
          <label className="flex items-center gap-2 font-body text-sm text-stone-700">
            <input
              type="checkbox"
              name="published"
              defaultChecked={defaultValues?.published ?? true}
              className="h-4 w-4 accent-[#4a1f36]"
            />
            Publié
          </label>
          <label className="flex items-center gap-2 font-body text-sm text-stone-700">
            <input
              type="checkbox"
              name="featured"
              defaultChecked={defaultValues?.featured ?? false}
              className="h-4 w-4 accent-[#4a1f36]"
            />
            Mis en avant
          </label>
        </div>
      </div>

      <div>
        <label htmlFor="content" className="font-body text-xs uppercase tracking-[0.14em] text-stone-500">
          Contenu du poème
        </label>
        <textarea
          id="content"
          name="content"
          required
          rows={18}
          defaultValue={defaultValues?.content}
          className="poem-text mt-2 w-full rounded-lg border border-stone-300 bg-white px-4 py-3 text-base leading-relaxed text-stone-800 outline-none focus:border-[#c9a15a] focus:ring-1 focus:ring-[#c9a15a]"
          placeholder="Écrivez ou collez le poème ici..."
        />
      </div>

      {state.status === "error" && (
        <p className="font-body text-sm text-red-600">{state.message}</p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="rounded-full bg-[#4a1f36] px-8 py-3 font-body text-sm font-semibold uppercase tracking-[0.12em] text-white transition hover:bg-[#3a1729] disabled:opacity-60"
      >
        {pending ? "Enregistrement..." : submitLabel}
      </button>
    </form>
  );
}
