import Link from "next/link";
import { getAllPoemsAdmin } from "@/lib/poems";
import { PoemRowActions } from "./poem-row-actions";

export const dynamic = "force-dynamic";

export default async function AdminPoemesPage() {
  const poems = await getAllPoemsAdmin();

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-bold text-[#16131c]">Poèmes</h1>
        <Link
          href="/admin/poemes/nouveau"
          className="rounded-full bg-[#4a1f36] px-6 py-2.5 font-body text-sm font-semibold uppercase tracking-[0.1em] text-white hover:bg-[#3a1729]"
        >
          + Nouveau poème
        </Link>
      </div>

      <div className="mt-8 overflow-hidden rounded-2xl border border-stone-200 bg-white">
        <table className="w-full text-left">
          <thead className="border-b border-stone-200 bg-stone-50">
            <tr>
              <th className="px-5 py-3 font-body text-xs uppercase tracking-[0.1em] text-stone-500">Titre</th>
              <th className="px-5 py-3 font-body text-xs uppercase tracking-[0.1em] text-stone-500">Catégorie</th>
              <th className="px-5 py-3 font-body text-xs uppercase tracking-[0.1em] text-stone-500">Vues</th>
              <th className="px-5 py-3 font-body text-xs uppercase tracking-[0.1em] text-stone-500">Statut</th>
              <th className="px-5 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {poems.map((poem) => (
              <tr key={poem.id}>
                <td className="px-5 py-4">
                  <Link
                    href={`/admin/poemes/${poem.id}`}
                    className="font-display text-sm font-semibold text-[#16131c] hover:text-[#4a1f36]"
                  >
                    {poem.title}
                  </Link>
                </td>
                <td className="px-5 py-4 font-body text-sm text-stone-500">{poem.category}</td>
                <td className="px-5 py-4 font-body text-sm text-stone-500">{poem.views}</td>
                <td className="px-5 py-4">
                  <PoemRowActions id={poem.id} published={poem.published} featured={poem.featured} />
                </td>
                <td className="px-5 py-4 text-right">
                  <Link
                    href={`/admin/poemes/${poem.id}`}
                    className="font-body text-xs uppercase tracking-[0.1em] text-[#4a1f36] hover:underline"
                  >
                    Modifier
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {poems.length === 0 && (
          <p className="p-8 text-center font-body text-sm text-stone-400">
            Aucun poème pour le moment. Commencez par en créer un.
          </p>
        )}
      </div>
    </div>
  );
}
