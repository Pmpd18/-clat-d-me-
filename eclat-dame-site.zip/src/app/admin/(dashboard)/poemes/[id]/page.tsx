import { notFound } from "next/navigation";
import { getPoemById } from "@/lib/poems";
import { PoemForm } from "../poem-form";
import { updatePoemAction } from "../../actions";

export const metadata = {
  title: "Modifier le poème",
};

export default async function EditPoemPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const poemId = Number(id);

  if (!Number.isInteger(poemId)) {
    notFound();
  }

  const poem = await getPoemById(poemId);
  if (!poem) {
    notFound();
  }

  const boundAction = updatePoemAction.bind(null, poem.id);

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-3xl font-bold text-[#16131c]">Modifier le poème</h1>
      <p className="mt-2 font-body text-sm text-stone-500">{poem.title}</p>

      <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-8">
        <PoemForm
          action={boundAction}
          submitLabel="Enregistrer les modifications"
          defaultValues={{
            title: poem.title,
            content: poem.content,
            category: poem.category,
            published: poem.published,
            featured: poem.featured,
          }}
        />
      </div>
    </div>
  );
}
