import { db } from "@/db";
import { messages } from "@/db/schema";
import { desc } from "drizzle-orm";
import { MessageActions } from "./message-actions";

export const dynamic = "force-dynamic";

export default async function AdminMessagesPage() {
  const allMessages = await db.select().from(messages).orderBy(desc(messages.createdAt));

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-[#16131c]">Messages</h1>
      <p className="mt-2 font-body text-sm text-stone-500">
        Messages reçus via le formulaire de contact.
      </p>

      <div className="mt-8 space-y-4">
        {allMessages.map((message) => (
          <div
            key={message.id}
            className={`rounded-2xl border p-6 ${
              message.read ? "border-stone-200 bg-white" : "border-[#c9a15a] bg-[#fdf8ee]"
            }`}
          >
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="font-display text-base font-semibold text-[#16131c]">
                  {message.name}
                </p>
                <p className="font-body text-xs text-stone-500">{message.email}</p>
                <p className="mt-1 font-body text-xs text-stone-400">
                  {new Intl.DateTimeFormat("fr-FR", { dateStyle: "long", timeStyle: "short" }).format(
                    message.createdAt
                  )}
                </p>
              </div>
              <MessageActions id={message.id} read={message.read} />
            </div>
            <p className="mt-4 whitespace-pre-line font-body text-sm leading-relaxed text-stone-700">
              {message.content}
            </p>
          </div>
        ))}

        {allMessages.length === 0 && (
          <p className="rounded-2xl border border-stone-200 bg-white p-8 text-center font-body text-sm text-stone-400">
            Aucun message pour le moment.
          </p>
        )}
      </div>
    </div>
  );
}
