"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteMessageAction, markMessageReadAction } from "../actions";

export function MessageActions({ id, read }: { id: number; read: boolean }) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        disabled={isPending}
        onClick={() => startTransition(async () => {
          await markMessageReadAction(id, !read);
          router.refresh();
        })}
        className={`rounded-full px-3 py-1 font-body text-xs uppercase tracking-[0.08em] ${
          read ? "bg-stone-100 text-stone-500" : "bg-emerald-100 text-emerald-700"
        }`}
      >
        {read ? "Marquer non lu" : "Marquer lu"}
      </button>
      <button
        type="button"
        disabled={isPending}
        onClick={() => {
          if (confirm("Supprimer ce message ?")) {
            startTransition(async () => {
              await deleteMessageAction(id);
              router.refresh();
            });
          }
        }}
        className="rounded-full bg-red-50 px-3 py-1 font-body text-xs uppercase tracking-[0.08em] text-red-600 hover:bg-red-100"
      >
        Supprimer
      </button>
    </div>
  );
}
