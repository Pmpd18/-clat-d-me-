import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { logoutAction } from "./actions";

const LINKS = [
  { href: "/admin", label: "Vue d'ensemble" },
  { href: "/admin/poemes", label: "Poèmes" },
  { href: "/admin/messages", label: "Messages" },
];

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  if (!session) {
    redirect("/admin/login");
  }

  return (
    <div className="min-h-screen bg-[#f5f1e8]">
      <header className="border-b border-stone-200 bg-[#16131c]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-8">
            <Link href="/admin" className="font-display text-xl font-bold text-[#e7cd9a]">
              Éclat d&apos;âme · Admin
            </Link>
            <nav className="hidden gap-6 sm:flex">
              {LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="font-body text-sm text-white/70 hover:text-[#e7cd9a]"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/" target="_blank" className="font-body text-xs uppercase tracking-[0.1em] text-white/50 hover:text-[#e7cd9a]">
              Voir le site
            </Link>
            <form action={logoutAction}>
              <button
                type="submit"
                className="rounded-full border border-white/20 px-4 py-1.5 font-body text-xs uppercase tracking-[0.1em] text-white/80 hover:border-[#c9a15a] hover:text-[#e7cd9a]"
              >
                Déconnexion
              </button>
            </form>
          </div>
        </div>
        <nav className="flex gap-6 border-t border-white/10 px-6 py-3 sm:hidden">
          {LINKS.map((link) => (
            <Link key={link.href} href={link.href} className="font-body text-xs text-white/70">
              {link.label}
            </Link>
          ))}
        </nav>
      </header>

      <div className="mx-auto max-w-6xl px-6 py-10">{children}</div>
    </div>
  );
}
