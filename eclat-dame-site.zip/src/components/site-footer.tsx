import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-[#16131c] text-white/60">
      <div className="mx-auto grid max-w-6xl gap-8 px-6 py-14 sm:grid-cols-3">
        <div>
          <p className="font-display text-xl font-bold text-[#e7cd9a]">Éclat d&apos;âme</p>
          <p className="mt-3 font-poem text-[15px] italic leading-relaxed text-white/50">
            « Un poème n&apos;est pas qu&apos;une suite de jolis mots, mais l&apos;expression
            d&apos;une âme, la mélodie silencieuse de la vie. »
          </p>
        </div>

        <div>
          <p className="font-body text-xs uppercase tracking-[0.18em] text-white/40">
            Navigation
          </p>
          <ul className="mt-3 space-y-2 font-body text-sm">
            <li><Link href="/" className="hover:text-[#e7cd9a]">Accueil</Link></li>
            <li><Link href="/poemes" className="hover:text-[#e7cd9a]">Tous les poèmes</Link></li>
            <li><Link href="/a-propos" className="hover:text-[#e7cd9a]">À propos de l&apos;auteur</Link></li>
            <li><Link href="/contact" className="hover:text-[#e7cd9a]">Contact</Link></li>
          </ul>
        </div>

        <div>
          <p className="font-body text-xs uppercase tracking-[0.18em] text-white/40">
            Espace privé
          </p>
          <ul className="mt-3 space-y-2 font-body text-sm">
            <li><Link href="/admin/login" className="hover:text-[#e7cd9a]">Connexion administrateur</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/5 px-6 py-5 text-center font-body text-xs text-white/30">
        © {new Date().getFullYear()} Éclat d&apos;âme — Tous droits réservés.
      </div>
    </footer>
  );
}
